Archived versions of CommandMiner before the shutdown of online features.
Online features like updating or mod installation will no longer work thus making these versions unstable.