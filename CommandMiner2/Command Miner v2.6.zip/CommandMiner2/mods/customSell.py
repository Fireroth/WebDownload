#-----Import global values-----
import sys
sys.path.append('../')
import globalHandler
#------------------------------

load_functions=["add_output", "update_top_label"]


def sellWorker(executable = True, command = "sell"):
    if globalHandler.ore_amount > 0:

        sale_amount = globalHandler.ore_amount * globalHandler.ore_multiplier
        globalHandler.money += sale_amount
        add_output("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", globalHandler.greenColor)
        add_output(f"You sold {globalHandler.ore_amount} {globalHandler.ore_name} for {sale_amount}$", globalHandler.lightGreenColor)
        add_output(f"Total money: {globalHandler.money}$", globalHandler.lightGreenColor)
        add_output("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", globalHandler.greenColor)
        globalHandler.ore_amount = 0
    else:
        add_output("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", globalHandler.lightRedColor)
        add_output("[Error] ", globalHandler.lightRedColor, f"You have no {globalHandler.ore_name} to sell.", globalHandler.redColor)
        add_output("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", globalHandler.lightRedColor)
    update_top_label()
 

def sellAlias(executable = True, command = "s"):
    sellWorker()