#-----Import global values-----
import sys
sys.path.append('../')
import globalHandler
#------------------------------
import tkinter as tk
from tkinter import ttk

load_functions=["update_top_label"]

def apply():
    globalHandler.money = money_var.get()
    globalHandler.tokens = tokens_var.get()
    update_top_label()


def maniWindow(executable = True, command = "manipulator"):
    global money_var, tokens_var

    if __name__ == "__main__":
        root_manipulator = tk.Tk()
        icon = tk.PhotoImage(file="./images/Icon2.png")
        root_manipulator.iconphoto(True, icon)
    else:
        root_manipulator = tk.Toplevel()
    
    root_manipulator.title("Var Manipulator")
    root_manipulator.geometry("300x170")
    root_manipulator.minsize(width=220, height=170)

    money_frame = ttk.LabelFrame(root_manipulator, text="Money")
    money_frame.pack(fill="x", padx=10, pady=5)

    money_var = tk.IntVar(value=globalHandler.money)
    money_spinbox = ttk.Spinbox(money_frame, from_=0, to=99999999999, textvariable=money_var)
    money_spinbox.pack(fill="x", padx=10, pady=5)

    tokens_frame = ttk.LabelFrame(root_manipulator, text="Tokens")
    tokens_frame.pack(fill="x", padx=10, pady=5)

    tokens_var = tk.IntVar(value=globalHandler.tokens)
    tokens_spinbox = ttk.Spinbox(tokens_frame, from_=0, to=99999999999, textvariable=tokens_var)
    tokens_spinbox.pack(fill="x", padx=10, pady=5)

    button_frame = tk.Frame(root_manipulator)
    button_frame.pack(fill="x", padx=10, pady=10)

    save_button = ttk.Button(button_frame, text="Save", command=apply)
    save_button.pack(side="left", padx=5)

    cancel_button = ttk.Button(button_frame, text="Cancel", command=root_manipulator.destroy)
    cancel_button.pack(side="right", padx=5)


    root_manipulator.mainloop()
