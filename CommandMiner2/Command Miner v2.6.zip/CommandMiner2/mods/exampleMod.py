#-----Import global values-----
import sys
sys.path.append('../')
import globalHandler
#------------------------------

#What functions to load from main.py
load_functions=["add_output", "update_top_label"]

#Function that can be accessed with command 'hello'
def hello_world(executable = True, command = "hello"):
    add_output("Hello World", globalHandler.blueColor)


def help_page(executable = True, command = "help example"):
    add_output("Available commands for example mod", globalHandler.blueColor)
    add_output("|| ", globalHandler.lightBlueColor,f"money: gives 500$", globalHandler.whiteColor)
    add_output("|| ", globalHandler.lightBlueColor,f"hello: hello world message", globalHandler.whiteColor)


def givemoney(executable = True, command = "money"):
    globalHandler.money += 500
    add_output("500$ have been added to your balance", globalHandler.cyanColor)
    update_top_label()


#Function that is not going to be added as command
def hello_world_nonExecutable():
    add_output("World Hello", globalHandler.blueColor)


#Function that is going to be called as soon as the mod loads
#Note: Function name have to be exactly 'init'
def init():
    add_output("Hello from exampleMod", globalHandler.orangeColor)

#'load_functions' and 'init()' components are optional