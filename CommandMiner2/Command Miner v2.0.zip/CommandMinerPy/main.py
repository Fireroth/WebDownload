import tkinter as tk
import tkinter.scrolledtext as scrolledtext
import random


program_version = "Beta Testing 1.0"
ore_amount = 0
money = 0
tokens = 0
pickaxe_level = 1
backpack_capacity = 50
output_font_size = 12
saveLoaded = "false"
ore_multiplier = 1

try:
    with open("save.txt", "r") as file:
        line = file.readlines()
        
        if len(line) >= 5:
            money = int(line[0].strip())
            ore_amount = int(line[1].strip())
            pickaxe_level = int(line[2].strip())
            backpack_capacity = int(line[3].strip())
            tokens = int(line[4].strip())

            print("Money:", money)
            print("ore amount:", ore_amount)
            print("pickaxe level:", pickaxe_level)
            print("backpack capacity:", backpack_capacity)
            print("tokens:", tokens)
            saveLoaded = "true"
        else:
            print("The 'save.txt' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'save.txt' file was not found.")
except ValueError:
    print("Error converting a value from the external file to a number.")


pickaxe_price = pickaxe_level*200
backpack_upgrade_cost = backpack_capacity*2

available_commands = {
    "ver": "Display current version",
    "help": "Display available commands",
    "exit": "Close the game",
    "mine": "Mine ores",
    "sell": "Sell ores and get money",
    "upgrade pickaxe": "Upgrade pickaxe",
    "upgrade backpack": "Increase backpack size",
    "clear": "Clear all text on the screen",
    "save": "Save your progress",
    "rebirth": ""
}


def update_top_label():
    top_label.config(text=f"Money: {money} | Tokens: {tokens} | Backpack: {ore_amount}/{backpack_capacity} | Pickaxe level: {pickaxe_level}")


def process_input():
    user_input = entry.get()
    if user_input.lower() == "exit":
        quit_app()
    elif user_input.lower() == "ver":
        add_output(f"Command MinerPy version: {program_version}", "lightgreen")
    elif user_input.lower() == "help":
        help_page()
    elif user_input.lower() == "mine" or user_input.lower() == "m":
        mine_ore()
    elif user_input.lower() == "sell" or user_input.lower() == "s":
        sell_ore()
    elif user_input.lower() == "upgrade pickaxe" or user_input.lower() == "u p" or user_input.lower() == "up p":
        upgrade_pickaxe()
    elif user_input.lower() == "upgrade backpack" or user_input.lower() == "u b" or user_input.lower() == "up b" or user_input.lower() == "up bp":
        upgrade_backpack()
    elif user_input.lower() == "rebirth":
        rebirth()
    elif user_input.lower() == "clear":
        clear_output()
    elif user_input.lower() == "save":
        save_progress()
    elif user_input.lower() == "":
        add_output(f"Empty command!", "red")
    else:
        add_output(f"Command {user_input} does not exist", 'red')
    entry.delete(0, "end")


def mine_ore():
    global ore_amount, backpack_capacity
    mined_amount = random.randint(1, 25) * pickaxe_level
    if ore_amount + mined_amount <= backpack_capacity:
        ore_amount += mined_amount
        add_output(f"You obtained {mined_amount} units of ore. Total ore in backpack: {ore_amount}", "lightgrey")
    elif ore_amount == backpack_capacity:
        add_output("Backpack is full. Sell some ore or increase the backpack capacity.", "red")
    else:
        ore_amount = backpack_capacity
        add_output(f"You obtained {mined_amount} units of ore. Total ore in backpack: {ore_amount}", "lightgrey")
    update_top_label()


def sell_ore():
    global ore_amount, money
    if ore_amount > 0:
        sale_amount = ore_amount * ore_multiplier
        money += sale_amount
        add_output(f"You sold {ore_amount} ores for {sale_amount} money. Total money: {money}", "lightgreen")
        ore_amount = 0
    else:
        add_output("You have no ore to sell.", "red")
    update_top_label()


def upgrade_pickaxe():
    global money, pickaxe_level, pickaxe_price
    if money >= pickaxe_price:
        money -= pickaxe_price
        pickaxe_level += 1
        pickaxe_price = pickaxe_level*200
        add_output(f"You upgraded the pickaxe to level {pickaxe_level}. New upgrade price: {pickaxe_price} money.", "lightblue")
    else:
        add_output(f"Not enough money to upgrade the pickaxe. Next upgrade cost {pickaxe_price} money.", "red")
    update_top_label()


def upgrade_backpack():
    global money, backpack_capacity, backpack_upgrade_cost
    if money >= backpack_upgrade_cost:
        money -= backpack_upgrade_cost
        backpack_capacity += 50
        backpack_upgrade_cost = backpack_capacity*2
        add_output(f"You increased backpack capacity to {backpack_capacity} ores. New upgrade price: {backpack_upgrade_cost} money.", "lightblue")
    else:
        add_output(f"Not enough money to increase backpack capacity. Next upgrade cost {backpack_upgrade_cost} money.", "red")
    update_top_label()


def help_page():
    add_output("Available commands:", "white")
    for command, description in available_commands.items():
        add_output(f"- {command}: {description}", "white")


def save_progress():
    try:
        with open("save.txt", "w") as file:
            file.write(str(money) + "\n")
            file.write(str(ore_amount) + "\n")
            file.write(str(pickaxe_level) + "\n")
            file.write(str(backpack_capacity) + "\n")
            file.write(str(tokens) + "\n")
        print("Data has been successfully written to the 'save.txt' file.")
        add_output("Saving succesfull.", "lightgreen")

    except IOError:
        print("Error writing to the 'save.txt' file.")

def rebirth():
    global backpack_capacity, pickaxe_level, tokens, money, ore_amount
    if pickaxe_level == 200:
        pickaxe_level = 1
        backpack_capacity = 50
        money = 0
        ore_amount = 0
        tokens += 1
        add_output("Rebirth was succesfull. +1 Token", "lightgreen")
        update_top_label()
    else:
        add_output("Failed to rebirth you need pickaxe level 200.", "red")


def clear_output():
    output_text.config(state=tk.NORMAL)
    output_text.delete(1.0, tk.END)
    output_text.config(state=tk.DISABLED)


def quit_app():
    root.destroy()


def add_output(text, color):
    output_text.config(state=tk.NORMAL)
    output_text.insert(tk.END, text + "\n", color)
    output_text.tag_config(color, foreground=color)
    output_text.see(tk.END)
    output_text.config(state=tk.DISABLED)


def on_enter(event):
    process_input()



root = tk.Tk()
root.title("Command MinerPy")
root.geometry("1000x600")
root.minsize(width=600, height=400)

icon = tk.PhotoImage(file="Icon.png")
root.iconphoto(True, icon)

root.tk_setPalette(background='#333', foreground='white')

top_label = tk.Label(root, text=f"Money: {money} | Tokens: {tokens} | Backpack: {ore_amount}/{backpack_capacity} | Pickaxe level: {pickaxe_level}", bg='#333', fg='white')
top_label.pack(pady=10)

output_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, state=tk.DISABLED, bg="#242424", fg="white", height=15, font=("", output_font_size))
output_text.pack(expand=True, fill="both")

entry = tk.Entry(root, bg='#444', fg='white', insertbackground='white', font=("", 17))
entry.pack(pady=5, fill='x')

button_frame = tk.Frame(root, bg='#333')
button_frame.pack()

quit_button = tk.Button(button_frame, text="Quit", command=quit_app, bg='#444', fg='white')
quit_button.pack(side=tk.LEFT, padx=5)

process_button = tk.Button(button_frame, text="Process", command=process_input, bg='#444', fg='white')
process_button.pack(side=tk.LEFT, padx=5)

help_button = tk.Button(button_frame, text="Help", command=help_page, bg='#444', fg='white')
help_button.pack(side=tk.LEFT, padx=5)

entry.bind("<Return>", on_enter)

if saveLoaded == "true":
    add_output("Save file loaded succesfully.", "lightgreen")
else:
    add_output("Save file was not loaded.", "red")

root.mainloop()
