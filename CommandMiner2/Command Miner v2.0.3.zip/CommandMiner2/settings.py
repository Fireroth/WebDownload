import tkinter as tk
from tkinter import messagebox


try:
    with open("./DAT/colorScheme_Dark.dat", "r") as file:
        line = file.readlines()
        
        if len(line) >= 6:
            globalBg = (line[0].strip())
            consoleBg = (line[1].strip())
            buttonBg = (line[2].strip())
            entryBg = (line[3].strip())
            titleFg = (line[4].strip())
            buttonFg = (line[5].strip())
            
        else:
            print("The 'colorScheme.dat' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'colorScheme.dat' file was not found.")

def successMsg():
    messagebox.showinfo("CommandMiner 2 Settings", "Successfully applied vaules")

def lightCS():
    try:
        with open("./DAT/config.dat", "w") as file:
            file.write(str("Light") + "\n")
        print("Data has been successfully written to the 'config.dat' file.")
        print("Light")
        successMsg()


    except IOError:
        print("Error writing to the 'config.txt' file.")

def darkCS():
    try:
        with open("./DAT/config.dat", "w") as file:
            file.write(str("Dark") + "\n")
        print("Data has been successfully written to the 'config.dat' file.")
        print("Dark")
        successMsg()

    except IOError:
        print("Error writing to the 'config.txt' file.")


def settings():
    settings_window = tk.Tk()
    settings_window.title("CommandMiner 2 Settings")
    settings_window.geometry("350x250")
    settings_window.minsize(width=300, height=200)
    settings_window.tk_setPalette(background=f'{globalBg}', foreground='white')
    settings_window.attributes("-topmost", True)


    warn_label = tk.Label(settings_window, text="Any changes apply after CM2 restarts", fg='#ff6e6e')
    warn_label.pack(pady=0)

    cs_label = tk.Label(settings_window, text="Select the color scheme", fg='white')
    cs_label.pack(pady=1)

    sett_button_frame = tk.Frame(settings_window, background=f'{globalBg}')
    sett_button_frame.pack()

    cs_button = tk.Button(sett_button_frame, text="Dark", command=darkCS, background=f'{buttonBg}', fg=f'{buttonFg}')
    cs_button.pack(side=tk.LEFT, padx=5)

    cs_button = tk.Button(sett_button_frame, text="Light", command=lightCS, background=f'{buttonBg}', fg=f'{buttonFg}')
    cs_button.pack(side=tk.LEFT, padx=5)

    sep_label = tk.Label(settings_window, text=f"--------------------------------------------", fg='white')
    sep_label.pack(pady=0)

    sett_label = tk.Label(settings_window, text=f"globalBg d=#333 c={globalBg}", fg='white')
    sett_label.pack(pady=0)
    sett_label = tk.Label(settings_window, text=f"consoleBg d=#242424 c={consoleBg}", fg='white')
    sett_label.pack(pady=0)
    sett_label = tk.Label(settings_window, text=f"buttonBg d=#444 c={buttonBg}", fg='white')
    sett_label.pack(pady=0)
    sett_label = tk.Label(settings_window, text=f"entryBg d=#444 c={entryBg}", fg='white')
    sett_label.pack(pady=0)
    sett_label = tk.Label(settings_window, text=f"titleFg d=#fff c={titleFg}", fg='white')
    sett_label.pack(pady=0)

    settings_window.mainloop()

if __name__ == "__main__":
    settings()
else:
    print("Opened as madule")