import tkinter as tk


# messagebox.showinfo("CommandMiner 2 Settings", "Successfully applied vaules")
def update():
    try:
        with open("./DAT/config.dat", "r") as file:
            line = file.readlines()
            
            if len(line) >= 4:
                colorsName = (line[0].strip())
                sepChar = (line[1].strip())
                output_font_size = (line[2].strip())
                auto_focus = (line[3].strip())

            else:
                print("The 'config.dat' file does not contain enough lines.")
    except FileNotFoundError:
        print("The 'config.dat' file was not found.")

    if colorsName == "Dark":
        cs1_button.configure(fg="#34e543")
        cs2_button.configure(fg=f'{buttonFg}')
        cs3_button.configure(fg=f'{buttonFg}')
        cs4_button.configure(fg=f'{buttonFg}')
    elif colorsName == "Light":
        cs2_button.configure(fg="#34e543")
        cs1_button.configure(fg=f'{buttonFg}')
        cs3_button.configure(fg=f'{buttonFg}')
        cs4_button.configure(fg=f'{buttonFg}')
    elif colorsName == "Pastel":
        cs3_button.configure(fg="#34e543")
        cs1_button.configure(fg=f'{buttonFg}')
        cs2_button.configure(fg=f'{buttonFg}')
        cs4_button.configure(fg=f'{buttonFg}')
    elif colorsName == "Custom":
        cs4_button.configure(fg="#34e543")
        cs1_button.configure(fg=f'{buttonFg}')
        cs2_button.configure(fg=f'{buttonFg}')
        cs3_button.configure(fg=f'{buttonFg}')

    if sepChar == "None":
        sc1_button.configure(fg="#34e543")
        sc2_button.configure(fg=f'{buttonFg}')
        sc3_button.configure(fg=f'{buttonFg}')
    elif sepChar == "Empty":
        sc2_button.configure(fg="#34e543")
        sc1_button.configure(fg=f'{buttonFg}')
        sc3_button.configure(fg=f'{buttonFg}')
    elif sepChar == "Dash":
        sc3_button.configure(fg="#34e543")
        sc1_button.configure(fg=f'{buttonFg}')
        sc2_button.configure(fg=f'{buttonFg}')

    if output_font_size == "9":
        ofs1_button.configure(fg="#34e543")
        ofs2_button.configure(fg=f'{buttonFg}')
        ofs3_button.configure(fg=f'{buttonFg}')
    elif output_font_size == "12":
        ofs2_button.configure(fg="#34e543")
        ofs1_button.configure(fg=f'{buttonFg}')
        ofs3_button.configure(fg=f'{buttonFg}')
    elif output_font_size == "17":
        ofs3_button.configure(fg="#34e543")
        ofs2_button.configure(fg=f'{buttonFg}')
        ofs1_button.configure(fg=f'{buttonFg}')

    if auto_focus == "True":
        af1_button.configure(fg="#34e543")
        af2_button.configure(fg=f'{buttonFg}')
    elif auto_focus == "False":
        af2_button.configure(fg="#34e543")
        af1_button.configure(fg=f'{buttonFg}')


def lightCS():
    global colorsName
    colorsName = "Light"
    saveConfig()


def darkCS():
    global colorsName
    colorsName = "Dark"
    saveConfig()


def pastelCS():
    global colorsName
    colorsName = "Pastel"
    saveConfig()
    

def customCS():
    global colorsName
    colorsName = "Custom"
    saveConfig()


def sepCharNone():
    global sepChar
    sepChar = "None"
    saveConfig()


def sepCharDash():
    global sepChar
    sepChar = "Dash"
    saveConfig()


def sepCharEmpty():
    global sepChar
    sepChar = "Empty"
    saveConfig()


def outputFSSmall():
    global output_font_size
    output_font_size = 9
    saveConfig()


def outputFSNormal():
    global output_font_size
    output_font_size = 12
    saveConfig()


def outputFSBig():
    global output_font_size
    output_font_size = 17
    saveConfig()


def autoFocusYes():
    global auto_focus
    auto_focus = True
    saveConfig()


def autoFocusNo():
    global auto_focus
    auto_focus = False
    saveConfig()


def saveConfig():
    try:
        with open("./DAT/config.dat", "w") as file:
            file.write(str(colorsName) + "\n")
            file.write(str(sepChar) + "\n")
            file.write(str(output_font_size) + "\n")
            file.write(str(auto_focus) + "\n")
        print("Data has been successfully written to the 'config.dat' file.")
        print(f"colorsName: {colorsName}, sepChar: {sepChar}, output_font_size: {output_font_size}, autoFocus: {auto_focus}")

    except IOError:
        print("Error writing to the 'config.dat' file.")
    update()


def settings():
    global cs1_button, cs2_button, cs3_button, cs4_button, sc1_button, sc2_button, sc3_button, ofs1_button, ofs2_button, ofs3_button, af1_button, af2_button
    settings_window = tk.Tk()
    settings_window.title("CommandMiner 2 Settings")
    settings_window.geometry("370x270")
    settings_window.minsize(width=335, height=230)
    settings_window.tk_setPalette(background=f'{globalBg}', foreground='white')
    #settings_window.attributes("-topmost", True)
    if __name__ == "__main__":
        icon = tk.PhotoImage(file="./images/Icon.png")
        settings_window.iconphoto(True, icon)

    warn_label = tk.Label(settings_window, text="Any changes apply after CM2 restarts", fg='#ff6e6e', font=("bold"))
    warn_label.pack(pady=0)




    cs_label = tk.Label(settings_window, text="Select the color scheme", fg=f'{titleFg}')
    cs_label.pack(pady=1)

    # Frame for colorScheme buttons
    cs_button_frame = tk.Frame(settings_window, background=f'{globalBg}')
    cs_button_frame.pack()

    cs1_button = tk.Button(cs_button_frame, text=" Dark ", command=darkCS, background=f'{buttonBg}', fg=f'{buttonFg}')
    cs1_button.pack(side=tk.LEFT, padx=5)

    cs2_button = tk.Button(cs_button_frame, text=" Light ", command=lightCS, background=f'{buttonBg}', fg=f'{buttonFg}')
    cs2_button.pack(side=tk.LEFT, padx=5)

    cs3_button = tk.Button(cs_button_frame, text=" Pastel ", command=pastelCS, background=f'{buttonBg}', fg=f'{buttonFg}')
    cs3_button.pack(side=tk.LEFT, padx=5)

    cs4_button = tk.Button(cs_button_frame, text=" Custom ", command=customCS, background=f'{buttonBg}', fg=f'{buttonFg}')
    cs4_button.pack(side=tk.LEFT, padx=5)



    sc_label = tk.Label(settings_window, text="Select spacing character between command outputs", fg=f'{titleFg}')
    sc_label.pack(pady=1)

    # Frame for sepChar buttons
    sc_button_frame = tk.Frame(settings_window, background=f'{globalBg}')
    sc_button_frame.pack()

    sc1_button = tk.Button(sc_button_frame, text=" No spacing ", command=sepCharNone, background=f'{buttonBg}', fg=f'{buttonFg}')
    sc1_button.pack(side=tk.LEFT, padx=5)

    sc2_button = tk.Button(sc_button_frame, text=" Empty line ", command=sepCharEmpty, background=f'{buttonBg}', fg=f'{buttonFg}')
    sc2_button.pack(side=tk.LEFT, padx=5)

    sc3_button = tk.Button(sc_button_frame, text=" --------- ", command=sepCharDash, background=f'{buttonBg}', fg=f'{buttonFg}')
    sc3_button.pack(side=tk.LEFT, padx=5)



    ofs_label = tk.Label(settings_window, text="Select the output font size", fg=f'{titleFg}')
    ofs_label.pack(pady=1)

    # Frame for outputFontSize buttons
    ofs_button_frame = tk.Frame(settings_window, background=f'{globalBg}')
    ofs_button_frame.pack()

    ofs1_button = tk.Button(ofs_button_frame, text=" Small ", command=outputFSSmall, background=f'{buttonBg}', fg=f'{buttonFg}')
    ofs1_button.pack(side=tk.LEFT, padx=5)

    ofs2_button = tk.Button(ofs_button_frame, text=" Normal ", command=outputFSNormal, background=f'{buttonBg}', fg=f'{buttonFg}')
    ofs2_button.pack(side=tk.LEFT, padx=5)

    ofs3_button = tk.Button(ofs_button_frame, text=" Big ", command=outputFSBig, background=f'{buttonBg}', fg=f'{buttonFg}')
    ofs3_button.pack(side=tk.LEFT, padx=5)



    af_label = tk.Label(settings_window, text="Auto focus to input field", fg=f'{titleFg}')
    af_label.pack(pady=1)

# Frame for autoFocus buttons
    af_button_frame = tk.Frame(settings_window, background=f'{globalBg}')
    af_button_frame.pack()

    af1_button = tk.Button(af_button_frame, text=" Yes ", command=autoFocusYes, background=f'{buttonBg}', fg=f'{buttonFg}')
    af1_button.pack(side=tk.LEFT, padx=5)

    af2_button = tk.Button(af_button_frame, text=" No ", command=autoFocusNo, background=f'{buttonBg}', fg=f'{buttonFg}')
    af2_button.pack(side=tk.LEFT, padx=5)

    update()
    settings_window.mainloop()

#--------------------------------------------------------------------
colorsName = "Dark"
sepChar = "None"
output_font_size = 12
auto_focus = False

try:
    with open("./DAT/config.dat", "r") as file:
        line = file.readlines()
        
        if len(line) >= 4:
            colorsName = (line[0].strip())
            sepChar = (line[1].strip())
            output_font_size = (line[2].strip())
            auto_focus = (line[3].strip())

        else:
            print("The 'config.dat' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'config.dat' file was not found.")



try:
    with open("./DAT/colorScheme_Dark.dat", "r") as file:
        line = file.readlines()
        
        if len(line) >= 6:
            globalBg = (line[0].strip())
            consoleBg = (line[1].strip())
            buttonBg = (line[2].strip())
            entryBg = (line[3].strip())
            titleFg = (line[4].strip())
            buttonFg = (line[5].strip())
            
        else:
            print("The 'colorScheme.dat' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'colorScheme.dat' file was not found.")

if __name__ == "__main__":
    settings()
else:
    print("Settings imported as module")