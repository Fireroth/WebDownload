import tkinter as tk
import tkinter.scrolledtext as scrolledtext
from random import randint

from settings import settings


def update_top_label():
    name_generator()
    top_label.config(text=f"Money: {money}$ | Tokens: {tokens} | Backpack: {ore_amount}/{backpack_capacity} | Pickaxe level: {pickaxe_level} | Ore: {ore_name}")


def process_input():
    
    user_input = entry.get()
    if user_input.lower() == "settings" or user_input.lower() == "set":
        entry.delete(0, "end")
        settings()
    elif user_input.lower() == "":
        add_output(f"Empty command!", redColor)
    elif function_dict.get(user_input):
        exec(function_dict[user_input])
    else:
        add_output(f"Command {user_input} does not exist", redColor)


    if sepChar == "Empty":
        add_output("", "")
    elif sepChar == "Dash":
        add_output("---------------------------------------------------", "")
    entry.delete(0, "end")


def mine_ore():
    global ore_amount, backpack_capacity, common_crate, uncommon_crate, rare_crate, epic_crate, legendary_crate

    mined_amount = randint(1, 5) * pickaxe_level + randint(0, 4)
    if ore_amount + mined_amount <= backpack_capacity:

        #crate generator-------------------------------------------------------------------
        if randint(1, 1000) >= 980:
            common_crate += 1
            add_output("You obtained 1 common crate", whiteColor)
        elif randint(1, 1700) >= 1690:
            uncommon_crate += 1
            add_output("You obtained 1 uncommon crate", lightGreenColor)
        elif randint(1, 3000) >= 2990:
            rare_crate += 1
            add_output("You obtained 1 rare crate", lightBlueColor)
        elif randint(1, 5000) >= 4996:
            epic_crate += 1
            add_output("You obtained 1 epic crate", purpleColor)
        elif randint(1, 7500) >= 7499:
            legendary_crate += 1
            add_output("You obtained 1 legendary crate", yellowColor)
        #crate generator-------------------------------------------------------------------

        ore_amount += mined_amount
        add_output(f"You obtained {mined_amount} units of {ore_name}. Total ore in backpack: {ore_amount}", "lightgrey")
    elif ore_amount == backpack_capacity and autosell == 1:
        sell_ore()
    elif ore_amount == backpack_capacity:
        add_output("Backpack is full. Sell some ore or free up space in backpack.", redColor)
    else:
        ore_amount = backpack_capacity
        add_output(f"You obtained {mined_amount} units of {ore_name}. Total ore in backpack: {ore_amount}", "lightgrey")
    update_top_label()


def sell_ore():
    global ore_amount, money
    if ore_amount > 0:

        sale_amount = ore_amount * ore_multiplier
        money += sale_amount
        add_output(f"You sold {ore_amount} {ore_name} for {sale_amount}$. Total money: {money}", lightGreenColor)
        ore_amount = 0
    else:
        add_output(f"You have no {ore_name} to sell.", redColor)
    update_top_label()


def upgrade_pickaxe():
    global money, pickaxe_level, pickaxe_price
    if money >= pickaxe_price:
        money -= pickaxe_price
        pickaxe_level += 1
        pickaxe_price = pickaxe_level*200
        add_output(f"You upgraded the pickaxe to level {pickaxe_level}. New upgrade price: {pickaxe_price}$.", lightBlueColor)
    else:
        add_output(f"Not enough money to upgrade the pickaxe. Next upgrade cost {pickaxe_price}$.", redColor)
    update_top_label()


def upgrade_backpack():
    global money, backpack_capacity, backpack_upgrade_cost
    if money >= backpack_upgrade_cost:
        money -= backpack_upgrade_cost
        backpack_capacity += 25
        backpack_upgrade_cost = backpack_capacity*2
        add_output(f"You increased backpack capacity to {backpack_capacity}. New upgrade price: {backpack_upgrade_cost}$.", lightBlueColor)
    else:
        add_output(f"Not enough money to increase backpack capacity. Next upgrade cost {backpack_upgrade_cost}$.", redColor)
    update_top_label()


def upgrade_ore():
    global tokens, ore_multiplier, ore_upgrade_cost
    if tokens >= ore_upgrade_cost:
        tokens -= ore_upgrade_cost
        ore_multiplier +=1
        ore_upgrade_cost = ore_upgrade_cost+2
        add_output(f"You increased ore to {ore_name} ores. New upgrade price: {ore_upgrade_cost} tokens.", lightBlueColor)
    else:
        add_output(f"Not enough tokens to increase ore. Next upgrade cost {ore_upgrade_cost} tokens.", redColor)
    update_top_label()


def open_crate_common():
    global money, common_crate
    if common_crate <= 0:
        add_output(f"You have no common crates to open.", redColor)
    else:
        common_crate -= 1
        crateMoney = randint(1, 200)
        if crateMoney < 150:
            crateMoney = 0
            add_output(f"You got {crateMoney}$ from common crate", redColor)
            add_output(f"Sorry but you got unlucky this time :(", redColor)
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from common crate", lightGreenColor)
    update_top_label()


def open_crate_uncommon():
    global money, uncommon_crate
    if uncommon_crate <= 0:
        add_output(f"You have no uncommon crates to open.", redColor)
    else:
        uncommon_crate -= 1
        crateMoney = randint(1, 400)
        if crateMoney < 475:
            crateMoney = 0
            add_output(f"You got {crateMoney}$ from uncommon crate", redColor)
            add_output(f"Sorry but you got unlucky this time :(", redColor)
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from uncommon crate", lightGreenColor)
    update_top_label()


def open_crate_rare():
    global money, rare_crate
    if rare_crate <= 0:
        add_output(f"You have no rare crates to open.", redColor)
    else:
        rare_crate -= 1
        crateMoney = randint(1, 625)
        if crateMoney < 620:
            crateMoney = 0
            add_output(f"You got {crateMoney}$ from rare crate", redColor)
            add_output(f"Sorry but you got unlucky this time :(", redColor)
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from rare crate", lightGreenColor)
    update_top_label()


def open_crate_epic():
    global money, epic_crate
    if epic_crate <= 0:
        add_output(f"You have no epic crates to open.", redColor)
    else:
        epic_crate -= 1
        crateMoney = randint(1, 925)
        if crateMoney > 50:
            crateMoney = 50
            add_output(f"You got {crateMoney}$ from epic crate", lightGreenColor)
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from epic crate", lightGreenColor)
    update_top_label()


def open_crate_legendary():
    global money, legendary_crate
    if legendary_crate <= 0:
        add_output(f"You have no legendary crates to open.", redColor)
    else:
        legendary_crate -= 1
        crateMoney = randint(1, 1300)
        if crateMoney > 150:
            crateMoney = 150
            add_output(f"You got {crateMoney}$ from epic crate", lightGreenColor)
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from legendary crate", lightGreenColor)
    update_top_label()


def stats():
    add_output(f"Money: {money}", lightBlueColor)
    add_output(f"Tokens: {tokens}", lightBlueColor)
    add_output(f"Pickaxe level: {pickaxe_level}", lightBlueColor)
    add_output(f"Backpack size: {backpack_capacity}", lightBlueColor)
    add_output(f"Ore multiplier: {ore_multiplier}", lightBlueColor)

def allstats():
    add_output(f"Money: {money}", lightBlueColor)
    add_output(f"Tokens: {tokens}", lightBlueColor)
    add_output(f"Pickaxe level: {pickaxe_level}", lightBlueColor)
    add_output(f"Pickaxe max mine: {pickaxe_level*5}", lightBlueColor)
    add_output(f"Pickaxe upgrade price: {pickaxe_price}$", lightBlueColor)
    add_output(f"Backpack size: {backpack_capacity}", lightBlueColor)
    add_output(f"Backpack upgrade price: {backpack_upgrade_cost}$", lightBlueColor)
    add_output(f"Ore multiplier: {ore_multiplier}", lightBlueColor)
    add_output(f"Ore name: {ore_name}", lightBlueColor)
    add_output(f"Ore amount in BP: {ore_amount}", lightBlueColor)
    add_output(f"Ore upgrade price: {ore_upgrade_cost} tokens", lightBlueColor)
    


def allCrates():
    add_output(f"Common: {common_crate}", whiteColor)
    add_output(f"Uncommon: {uncommon_crate}", lightGreenColor)
    add_output(f"Rare: {rare_crate}", lightBlueColor)
    add_output(f"Epic: {epic_crate}", purpleColor)
    add_output(f"Legendary: {legendary_crate}", yellowColor)


def help_page():
    add_output("Available commands:", blueColor)
    for command, description in available_commands.items():
        add_output(f"- {command}: {description}", whiteColor)


def token_shop():
    global autosell, rebirth_token_reward, rebirth_token_reward_next_price, autosell_next_price

    add_output("Autosell", lightGreenColor)
    add_output(f"|| Current level: {autosell}", lightGreenColor)
    add_output(f"|| Upgrade price: {autosell_next_price}", lightGreenColor)
    add_output(f"|| Upgrade command: buy autosell", lightGreenColor)
    add_output("", "")
    add_output("Rebirth token reward", pinkColor)
    add_output(f"|| Current level: {rebirth_token_reward}", pinkColor)
    add_output(f"|| Upgrade price: {rebirth_token_reward_next_price}", pinkColor)
    add_output(f"|| Upgrade command: buy rebreward", pinkColor)


def buy_autosell():
    global tokens, autosell, autosell_next_price
    if autosell == 1:
        add_output("Autosell has reached its maximum level", redColor)
    elif tokens >= autosell_next_price:
        tokens -= autosell_next_price
        autosell = 1
        add_output(f"Autosell has been upgraded to level 1 for {autosell_next_price} tokens", lightGreenColor)
        autosell_next_price = 0
        update_top_label()
    else:
        add_output("Not enough tokens to buy Autosell", redColor)


def buy_rebreward():
    global tokens, rebirth_token_reward_next_price, rebirth_token_reward
    if rebirth_token_reward == 1:
        add_output("Rebirth token reward has reached its maximum level", redColor)
    elif tokens >= rebirth_token_reward_next_price:
        tokens -= rebirth_token_reward_next_price
        rebirth_token_reward = 1
        add_output(f"Rebirth token reward has been upgraded to level 1 for {rebirth_token_reward_next_price} tokens", lightGreenColor)
        rebirth_token_reward_next_price = 0
        update_top_label()
    else:
        add_output("Not enough tokens to buy Rebirth token reward", redColor)


def save_progress():
    try:
        with open("./DAT/save.dat", "w") as file:
            file.write(str(money) + "\n")
            file.write(str(ore_amount) + "\n")
            file.write(str(pickaxe_level) + "\n")
            file.write(str(backpack_capacity) + "\n")
            file.write(str(tokens) + "\n")
            file.write(str(ore_multiplier) + "\n")
            file.write(str(common_crate) + "\n")
            file.write(str(uncommon_crate) + "\n")
            file.write(str(rare_crate) + "\n")
            file.write(str(epic_crate) + "\n")
            file.write(str(legendary_crate) + "\n")
            file.write(str(autosell) + "\n")
            file.write(str(rebirth_token_reward) + "\n")
        print("Data has been successfully written to the 'save.dat' file.")
        add_output("Saving succesfull.", lightGreenColor)

    except IOError:
        print("Error writing to the 'save.txt' file.")


def reset_progress():
    global money, pickaxe_level, backpack_capacity, ore_amount, tokens, ore_multiplier, common_crate, uncommon_crate, rare_crate, epic_crate, legendary_crate, autosell, rebirth_token_reward
    money = 0
    pickaxe_level = 1
    backpack_capacity = 50
    ore_amount = 0
    tokens = 0
    ore_multiplier = 1
    common_crate = 0
    uncommon_crate = 0
    rare_crate = 0
    epic_crate = 0
    legendary_crate = 0
    autosell = 0
    rebirth_token_reward = 0
    update_top_label()
    add_output("Reset succesfull.", lightGreenColor)
    add_output("Save to make the changes permanent", lightGreenColor)

def name_generator():
    global ore_name
    ore_names_dict = {
        1: "Coal",
        2: "Iron",
        3: "Copper",
        4: "Lapis",
        5: "Quartz",
        6: "Gold",
        7: "Redstone",
        8: "Diamond",
        9: "Emerald",
        10: "Netherite",
        11: "Bedrock"
    }
    if ore_multiplier >= 11:
        ore_name = f"Bedrock+{ore_multiplier-11}"
    else:
        ore_name = ore_names_dict[ore_multiplier]

    """
    tools_names_dict = {
        1: "Wooden",
        2: "Stone",
        3: "Copper",
        4: "Iron",
        5: "Quartz",
        6: "Golden",
        7: "Redstone",
        8: "Diamond",
        9: "Emerald",
        10: "Netherite",
        11: "Obsidian"
    }
    """


def rebirth():
    global backpack_capacity, pickaxe_level, tokens, money, ore_amount
    if pickaxe_level >= 200:
        pickaxe_level = 1
        backpack_capacity = 50
        money = 0
        ore_amount = 0
        if rebirth_token_reward == 1:
            tokens += 2
            add_output("Rebirth was succesfull. +2 Tokens", lightGreenColor)
        else:
            tokens += 1
            add_output("Rebirth was succesfull. +1 Token", lightGreenColor)
        update_top_label()
    else:
        add_output("Failed to rebirth you need pickaxe level 200 or higher.", redColor)


def colorOutputTest():
    add_output("█████████████████████████████ redColor", redColor)
    add_output("█████████████████████████████ lightRedColor", lightRedColor)
    add_output("█████████████████████████████ darkRedColor", darkRedColor)
    add_output("█████████████████████████████ pinkColor", pinkColor)
    add_output("█████████████████████████████ orangeColor", orangeColor)
    add_output("█████████████████████████████ lightOrangeColor", lightOrangeColor)
    add_output("█████████████████████████████ darkOrangeColor", darkOrangeColor)
    add_output("█████████████████████████████ yellowColor", yellowColor)
    add_output("█████████████████████████████ lightYellowColor", lightYellowColor)
    add_output("█████████████████████████████ darkYellowColor", darkYellowColor)
    add_output("█████████████████████████████ greenColor", greenColor)
    add_output("█████████████████████████████ lightGreenColor", lightGreenColor)
    add_output("█████████████████████████████ darkGreenColor", darkGreenColor)
    add_output("█████████████████████████████ limeColor", limeColor)
    add_output("█████████████████████████████ blueColor", blueColor)
    add_output("█████████████████████████████ lightBlueColor", lightBlueColor)
    add_output("█████████████████████████████ darkBlueColor", darkBlueColor)
    add_output("█████████████████████████████ cyanColor", cyanColor)
    add_output("█████████████████████████████ whiteColor", whiteColor)
    add_output("█████████████████████████████ greyColor", greyColor)
    add_output("█████████████████████████████ blackColor", blackColor)
    add_output("█████████████████████████████ purpleColor", purpleColor)


def clear_output():
    output_text.config(state=tk.NORMAL)
    output_text.delete(1.0, tk.END)
    output_text.config(state=tk.DISABLED)


def quit_app():
    root.destroy()


def add_output(text, color):
    output_text.config(state=tk.NORMAL)
    output_text.insert(tk.END, text + "\n", color)
    output_text.tag_config(color, foreground=color)
    output_text.see(tk.END)
    output_text.config(state=tk.DISABLED)


def on_enter(event):
    process_input()


def on_entry_focus_in(event):
    if entry.get() == placeholder_text:
        entry.delete(0, tk.END)
        entry.configure(show="")
        entry.configure(fg=f'{titleFg}')


def on_entry_focus_out(event):
    if entry.get() == "":
        entry.insert(0, placeholder_text)
        entry.configure(show="")
        entry.configure(fg=whiteColor)

#--------------------------------------------------------------------

ver = "2.2"
verName = "Customization & performance update"
ore_amount = 0
money = 0
tokens = 0
pickaxe_level = 1
backpack_capacity = 50
saveLoaded = "false"
ore_multiplier = 1
ore_name = "Coal"
common_crate = 0
uncommon_crate = 0
rare_crate = 0
epic_crate = 0
legendary_crate = 0
autosell = 0
rebirth_token_reward = 0

try:
    with open("./DAT/save.dat", "r") as file:
        line = file.readlines()
        
        if len(line) >= 13:
            money = int(line[0].strip())
            ore_amount = int(line[1].strip())
            pickaxe_level = int(line[2].strip())
            backpack_capacity = int(line[3].strip())
            tokens = int(line[4].strip())
            ore_multiplier = int(line[5].strip())
            common_crate = int(line[6].strip())
            uncommon_crate = int(line[7].strip())
            rare_crate = int(line[8].strip())
            epic_crate = int(line[9].strip())
            legendary_crate = int(line[10].strip())
            autosell = int(line[11].strip())
            rebirth_token_reward = int(line[12].strip())

            print("Money:", money)
            print("ore amount:", ore_amount)
            print("pickaxe level:", pickaxe_level)
            print("backpack capacity:", backpack_capacity)
            print("tokens:", tokens)
            print("ore multiplier:", ore_multiplier)
            print("common crates:", common_crate)
            print("uncommon crates:", uncommon_crate)
            print("rare crates:", rare_crate)
            print("epic crates:", epic_crate)
            print("legendary crates:", legendary_crate)
            print("autosell:", autosell)
            print("rebirth_token_reward:", rebirth_token_reward)
            saveLoaded = "true"
        else:
            print("The 'save.dat' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'save.dat' file was not found.")
except ValueError:
    print("Error converting a value from 'save.dat' file to a number.")


try:
    with open("./DAT/config.dat", "r") as file:
        line = file.readlines()
        
        if len(line) >= 4:
            colorsName = (line[0].strip())
            sepChar = (line[1].strip())
            output_font_size = int((line[2].strip()))
            auto_focus = (line[3].strip())

            print("colorsName:", colorsName)
            print("sepChar:", sepChar)
            print("output_font_size:", output_font_size)
            print("auto_focus:", auto_focus)

        else:
            print("The 'config.dat' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'config.dat' file was not found.")


try:
    with open(f"./DAT/colorScheme_{colorsName}.dat", "r") as file:
        line = file.readlines()
        
        if len(line) >= 28:
            globalBg = (line[0].strip())
            consoleBg = (line[1].strip())
            buttonBg = (line[2].strip())
            entryBg = (line[3].strip())
            titleFg = (line[4].strip())
            buttonFg = (line[5].strip())

            redColor = (line[6].strip())
            lightRedColor = (line[7].strip())
            darkRedColor = (line[8].strip())
            pinkColor = (line[9].strip())
            orangeColor = (line[10].strip())
            lightOrangeColor = (line[11].strip())
            darkOrangeColor = (line[12].strip())
            yellowColor = (line[13].strip())
            lightYellowColor = (line[14].strip())
            darkYellowColor = (line[15].strip())
            greenColor = (line[16].strip())
            lightGreenColor = (line[17].strip())
            darkGreenColor = (line[18].strip())
            limeColor = (line[19].strip())
            blueColor = (line[20].strip())
            lightBlueColor = (line[21].strip())
            darkBlueColor = (line[22].strip())
            cyanColor = (line[23].strip())
            whiteColor = (line[24].strip())
            greyColor = (line[25].strip())
            blackColor = (line[26].strip())
            purpleColor = (line[27].strip())

        else:
            print("The 'colorScheme.dat' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'colorScheme.dat' file was not found.")

pickaxe_price = pickaxe_level*200
backpack_upgrade_cost = backpack_capacity*2
ore_upgrade_cost = ore_multiplier+2

if autosell == 0:
    autosell_next_price = 10
else:
    autosell_next_price = 0

if rebirth_token_reward == 0:
    rebirth_token_reward_next_price = 5
else:
    rebirth_token_reward_next_price = 0

available_commands = {
    "ver": "Display current version",
    "help": "Display available commands",
    "exit": "Close CommandMiner 2",
    "mine": "Mine ores",
    "sell": "Sell ores and get money",
    "upgrade pickaxe": "Upgrade pickaxe",
    "upgrade backpack": "Increase backpack size",
    "upgrade ore": "Upgrade your ore",
    "open <crate_tier>": "Open a desired crate",
    "clear": "Clear all text on the screen",
    "save": "Save your progress",
    "rebirth": "Exchange progress for tokens",
    "tokenshop": "Exchange tokens for skills",
    "stats": "See your statistics",
    "reset": "Resets your progress",
    "settings": "Configure CommandMiner 2",
    "crates": "See the amount of crates you have"
}

function_dict = {
    'exit': 'quit_app()',
    'ver': 'add_output(f"CommandMiner 2 version: {ver}\\n{verName}", lightGreenColor)',
    'help': 'help_page()',
    'mine': 'mine_ore()',
    'm': 'mine_ore()',
    'sell': 'sell_ore()',
    's': 'sell_ore()',
    'upgrade pickaxe': 'upgrade_pickaxe()',
    'u p': 'upgrade_pickaxe()',
    'up p': 'upgrade_pickaxe()',
    'upgrade backpack': 'upgrade_backpack()',
    'u b': 'upgrade_backpack()',
    'up b': 'upgrade_backpack()',
    'up bp': 'upgrade_backpack()',
    'u bp': 'upgrade_backpack()',
    'upgrade ore': 'upgrade_ore()',
    'up o': 'upgrade_ore()',
    'u o': 'upgrade_ore()',
    'up ore': 'upgrade_ore()',
    'open common': 'open_crate_common()',
    'o common': 'open_crate_common()',
    'o c': 'open_crate_common()',
    'open c': 'open_crate_common()',
    'open uncommon': 'open_crate_uncommon()',
    'o uncommon': 'open_crate_uncommon()',
    'o u': 'open_crate_uncommon()',
    'open u': 'open_crate_uncommon()',
    'open rare': 'open_crate_rare()',
    'o rare': 'open_crate_rare()',
    'o r': 'open_crate_rare()',
    'open r': 'open_crate_rare()',
    'open epic': 'open_crate_epic()',
    'o epic': 'open_crate_epic()',
    'o e': 'open_crate_epic()',
    'open e': 'open_crate_epic()',
    'open legendary': 'open_crate_legendary()',
    'o legendary': 'open_crate_legendary()',
    'o l': 'open_crate_legendary()',
    'open l': 'open_crate_legendary()',
    'tokenshop': 'token_shop()',
    'token shop': 'token_shop()',
    'tshop': 'token_shop()',
    'ts': 'token_shop()',
    'rebirth': 'rebirth()',
    'clear': 'clear_output()',
    'cls': 'clear_output()',
    'save': 'save_progress()',
    'stats': 'allstats()',
    'update': 'add_output(f"WIP!\\nGet the latest version at https://fireroth.github.io/projects/cmdminer2", whiteColor)',
    'lstats': 'stats()',
    'crates': 'allCrates()',
    'reset': 'reset_progress()',
    'buy': 'add_output(f"Invalid syntax.\\nUse buy <skill_name>", redColor)',
    'buy autosell': 'buy_autosell()',
    'buy rebreward': 'buy_rebreward()',
    'colortest':'colorOutputTest()'
}

name_generator()

root = tk.Tk()
root.title("CommandMiner 2")
root.geometry("900x500")
root.minsize(width=600, height=400)

icon = tk.PhotoImage(file="./images/Icon.png")
root.iconphoto(True, icon)

root.tk_setPalette(background=f'{globalBg}', foreground=whiteColor)

top_label = tk.Label(root, text=f"Money: {money}$ | Tokens: {tokens} | Backpack: {ore_amount}/{backpack_capacity} | Pickaxe level: {pickaxe_level} | Ore: {ore_name}", bg=f"{globalBg}", fg=f"{titleFg}", font=("", 10))
top_label.pack(pady=10)

output_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, state=tk.DISABLED, background=f'{consoleBg}', fg=whiteColor, height=15, font=("", output_font_size))
output_text.pack(expand=True, fill="both")

placeholder_text = "Enter command here..."
entry = tk.Entry(root, background=f'{entryBg}', fg=f'{titleFg}', insertbackground=whiteColor, font=("", 17))
entry.insert(0, placeholder_text)
entry.bind("<FocusIn>", on_entry_focus_in)
entry.bind("<FocusOut>", on_entry_focus_out)
if auto_focus == "True":
    entry.focus()
entry.pack(pady=5, fill='x')

button_frame = tk.Frame(root, background=f'{globalBg}')
button_frame.pack()

quit_button = tk.Button(button_frame, text="Quit", command=quit_app, background=f'{buttonBg}', fg=f'{buttonFg}')
quit_button.pack(side=tk.LEFT, padx=5, pady=(0,5))

process_button = tk.Button(button_frame, text="Process", command=process_input, background=f'{buttonBg}', fg=f'{buttonFg}')
process_button.pack(side=tk.LEFT, padx=5, pady=(0,5))


help_button = tk.Button(button_frame, text="Help", command=help_page, background=f'{buttonBg}', fg=f'{buttonFg}')
help_button.pack(side=tk.LEFT, padx=5, pady=(0,5))

settings_button = tk.Button(button_frame, text="Settings", command=settings, background=f'{buttonBg}', fg=f'{buttonFg}')
settings_button.pack(side=tk.LEFT, padx=5, pady=(0,5))


entry.bind("<Return>", on_enter)

add_output(f"CommandMiner 2 {verName}", lightGreenColor)
if saveLoaded == "true":
    add_output("Save file loaded succesfully.", lightGreenColor)
else:
    add_output("Save file was not loaded.", redColor)

root.mainloop()