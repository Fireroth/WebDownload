import globalHandler

def load_config():
    try:
        with open("./data/config.dat", "r") as file:
            line = file.readlines()
            
            if len(line) >= 16:
                globalHandler.colorsName = (line[1].strip())
                globalHandler.sepChar = (line[3].strip())
                globalHandler.output_font_size = (line[5].strip())
                globalHandler.auto_focus = eval((line[7].strip()))
                globalHandler.autoSave = eval((line[9].strip()))
                globalHandler.exitWarn = eval((line[11].strip()))
                globalHandler.mod_support = eval((line[13].strip()))
                globalHandler.accs_support = eval((line[15].strip()))

                print("[IOHandler][Config][Read] colorsName:", globalHandler.colorsName,
                    "\n[IOHandler][Config][Read] sepChar:", globalHandler.sepChar,
                    "\n[IOHandler][Config][Read] output_font_size:", globalHandler.output_font_size,
                    "\n[IOHandler][Config][Read] auto_focus:", globalHandler.auto_focus,
                    "\n[IOHandler][Config][Read] autoSave:", globalHandler.autoSave,
                    "\n[IOHandler][Config][Read] exitWarn:", globalHandler.exitWarn,
                    "\n[IOHandler][Config][Read] mod_support:", globalHandler.mod_support,
                    "\n[IOHandler][Config][Read] accs_support:", globalHandler.accs_support)
            else:
                print("The 'config.dat' file does not contain enough lines.")
    except FileNotFoundError:
        print("The 'config.dat' file was not found.")


def save_config():
    try:
        with open("./data/config.dat", "w") as file:
            file.write(str("[colorsName]") + "\n")
            file.write(str(globalHandler.colorsName) + "\n")
            file.write(str("[sepChar]") + "\n")
            file.write(str(globalHandler.sepChar) + "\n")
            file.write(str("[output_font_size]") + "\n")
            file.write(str(globalHandler.output_font_size) + "\n")
            file.write(str("[auto_focus]") + "\n")
            file.write(str(globalHandler.auto_focus) + "\n")
            file.write(str("[autoSave]") + "\n")
            file.write(str(globalHandler.autoSave) + "\n")
            file.write(str("[exitWarn]") + "\n")
            file.write(str(globalHandler.exitWarn) + "\n")
            file.write(str("[mod_support]") + "\n")
            file.write(str(globalHandler.mod_support) + "\n")
            file.write(str("[accs_support]") + "\n")
            file.write(str(globalHandler.accs_support))

            print("[IOHandler][Config][Write] colorsName:", globalHandler.colorsName,
                "\n[IOHandler][Config][Write] sepChar:", globalHandler.sepChar,
                "\n[IOHandler][Config][Write] output_font_size:", globalHandler.output_font_size,
                "\n[IOHandler][Config][Write] autoFocus:", globalHandler.auto_focus,
                "\n[IOHandler][Config][Write] autoSave:", globalHandler.autoSave,
                "\n[IOHandler][Config][Write] exitWarn:", globalHandler.exitWarn,
                "\n[IOHandler][Config][Write] mod_support:", globalHandler.mod_support,
                "\n[IOHandler][Config][Write] accs_support:", globalHandler.accs_support)

    except IOError:
        print("Error writing to the 'config.dat' file.")


def load_save():
    try:
        with open(f"./data/save_{globalHandler.account}.dat", "r") as file:
            line = file.readlines()
            
            if len(line) >= 36:
                globalHandler.money = int(line[1].strip())
                globalHandler.ore_amount = int(line[3].strip())
                globalHandler.pickaxe_level = int(line[5].strip())
                globalHandler.backpack_capacity = int(line[7].strip())
                globalHandler.backpack_level = int(line[9].strip())
                globalHandler.tokens = int(line[11].strip())
                globalHandler.ore_multiplier = int(line[13].strip())
                globalHandler.common_crate = int(line[15].strip())
                globalHandler.uncommon_crate = int(line[17].strip())
                globalHandler.rare_crate = int(line[19].strip())
                globalHandler.epic_crate = int(line[21].strip())
                globalHandler.legendary_crate = int(line[23].strip())
                globalHandler.autosell = int(line[25].strip())
                globalHandler.rebirth_token_reward = int(line[27].strip())
                globalHandler.rebirth_amount = int(line[29].strip())
                globalHandler.minimum_mined = int(line[31].strip())
                globalHandler.auto_crate_open = int(line[33].strip())
                globalHandler.double_mine = int(line[35].strip())

                print("[IOHandler][Save][Read] money:", globalHandler.money,
                    "\n[IOHandler][Save][Read] ore amount:", globalHandler.ore_amount,
                    "\n[IOHandler][Save][Read] pickaxe level:", globalHandler.pickaxe_level,
                    "\n[IOHandler][Save][Read] backpack capacity:", globalHandler.backpack_capacity,
                    "\n[IOHandler][Save][Read] backpack level:", globalHandler.backpack_level,
                    "\n[IOHandler][Save][Read] tokens:", globalHandler.tokens,
                    "\n[IOHandler][Save][Read] ore multiplier:", globalHandler.ore_multiplier,
                    "\n[IOHandler][Save][Read] common crates:", globalHandler.common_crate,
                    "\n[IOHandler][Save][Read] uncommon crates:", globalHandler.uncommon_crate,
                    "\n[IOHandler][Save][Read] rare crates:", globalHandler.rare_crate,
                    "\n[IOHandler][Save][Read] epic crates:", globalHandler.epic_crate,
                    "\n[IOHandler][Save][Read] legendary crates:", globalHandler.legendary_crate,
                    "\n[IOHandler][Save][Read] autosell:", globalHandler.autosell,
                    "\n[IOHandler][Save][Read] rebirth_token_reward:", globalHandler.rebirth_token_reward,
                    "\n[IOHandler][Save][Read] rebirth_amount:", globalHandler.rebirth_amount,
                    "\n[IOHandler][Save][Read] minimum_mined:", globalHandler.minimum_mined,
                    "\n[IOHandler][Save][Read] auto_crate_open:", globalHandler.auto_crate_open,
                    "\n[IOHandler][Save][Read] double_mine:", globalHandler.double_mine)

                globalHandler.saveLoaded = True
            else:
                print("The 'save.dat' file does not contain enough lines.")
    except FileNotFoundError:
        print("The 'save.dat' file was not found.")
    except ValueError:
        print("Error converting a value from 'save.dat' file to a number.")


def save_progress(silent = False):
    try:
        with open(f"./data/save_{globalHandler.account}.dat", "w") as file:
            file.write(str("[money]") + "\n")
            file.write(str(globalHandler.money) + "\n")
            file.write(str("[ore_amount]") + "\n")
            file.write(str(globalHandler.ore_amount) + "\n")
            file.write(str("[pickaxe_level]") + "\n")
            file.write(str(globalHandler.pickaxe_level) + "\n")
            file.write(str("[backpack_capacity]") + "\n")
            file.write(str(globalHandler.backpack_capacity) + "\n")
            file.write(str("[backpack_level]") + "\n")
            file.write(str(globalHandler.backpack_level) + "\n")
            file.write(str("[tokens]") + "\n")
            file.write(str(globalHandler.tokens) + "\n")
            file.write(str("[ore_multiplier]") + "\n")
            file.write(str(globalHandler.ore_multiplier) + "\n")
            file.write(str("[common_crate]") + "\n")
            file.write(str(globalHandler.common_crate) + "\n")
            file.write(str("[uncommon_crate]") + "\n")
            file.write(str(globalHandler.uncommon_crate) + "\n")
            file.write(str("[rare_crate]") + "\n")
            file.write(str(globalHandler.rare_crate) + "\n")
            file.write(str("[epic_crate]") + "\n")
            file.write(str(globalHandler.epic_crate) + "\n")
            file.write(str("[legendary_crate]") + "\n")
            file.write(str(globalHandler.legendary_crate) + "\n")
            file.write(str("[autosell]") + "\n")
            file.write(str(globalHandler.autosell) + "\n")
            file.write(str("[rebirth_token_reward]") + "\n")
            file.write(str(globalHandler.rebirth_token_reward) + "\n")
            file.write(str("[rebirth_amount]") + "\n")
            file.write(str(globalHandler.rebirth_amount) + "\n")          
            file.write(str("[minimum_mined]") + "\n")
            file.write(str(globalHandler.minimum_mined) + "\n")
            file.write(str("[auto_crate_open]") + "\n")
            file.write(str(globalHandler.auto_crate_open) + "\n")
            file.write(str("[double_mine]") + "\n")
            file.write(str(globalHandler.double_mine))

            if silent == False:
                print("[IOHandler][Save][Write] money:", globalHandler.money,
                        "\n[IOHandler][Save][Write] ore amount:", globalHandler.ore_amount,
                        "\n[IOHandler][Save][Write] pickaxe level:", globalHandler.pickaxe_level,
                        "\n[IOHandler][Save][Write] backpack capacity:", globalHandler.backpack_capacity,
                        "\n[IOHandler][Save][Write] backpack level:", globalHandler.backpack_level,
                        "\n[IOHandler][Save][Write] tokens:", globalHandler.tokens,
                        "\n[IOHandler][Save][Write] ore multiplier:", globalHandler.ore_multiplier,
                        "\n[IOHandler][Save][Write] common crates:", globalHandler.common_crate,
                        "\n[IOHandler][Save][Write] uncommon crates:", globalHandler.uncommon_crate,
                        "\n[IOHandler][Save][Write] rare crates:", globalHandler.rare_crate,
                        "\n[IOHandler][Save][Write] epic crates:", globalHandler.epic_crate,
                        "\n[IOHandler][Save][Write] legendary crates:", globalHandler.legendary_crate,
                        "\n[IOHandler][Save][Write] autosell:", globalHandler.autosell,
                        "\n[IOHandler][Save][Write] rebirth_token_reward:", globalHandler.rebirth_token_reward,
                        "\n[IOHandler][Save][Write] rebirth_amount:", globalHandler.rebirth_amount,
                        "\n[IOHandler][Save][Write] minimum_mined:", globalHandler.minimum_mined,
                        "\n[IOHandler][Save][Write] auto_crate_open:", globalHandler.auto_crate_open,
                        "\n[IOHandler][Save][Write] double_mine:", globalHandler.double_mine)

    except IOError:
        print("Error writing to'save.txt' file.")


def load_theme():
    try:
        with open(f"./data/colorScheme_{globalHandler.colorsName}.dat", "r") as file:
            line = file.readlines()
            
            if len(line) >= 29:
                globalHandler.globalBg = (line[0].strip())
                globalHandler.consoleBg = (line[1].strip())
                globalHandler.buttonBg = (line[2].strip())
                globalHandler.entryBg = (line[3].strip())
                globalHandler.titleFg = (line[4].strip())
                globalHandler.buttonFg = (line[5].strip())

                globalHandler.redColor = (line[6].strip())
                globalHandler.lightRedColor = (line[7].strip())
                globalHandler.darkRedColor = (line[8].strip())
                globalHandler.pinkColor = (line[9].strip())
                globalHandler.orangeColor = (line[10].strip())
                globalHandler.lightOrangeColor = (line[11].strip())
                globalHandler.darkOrangeColor = (line[12].strip())
                globalHandler.yellowColor = (line[13].strip())
                globalHandler.lightYellowColor = (line[14].strip())
                globalHandler.darkYellowColor = (line[15].strip())
                globalHandler.greenColor = (line[16].strip())
                globalHandler.lightGreenColor = (line[17].strip())
                globalHandler.darkGreenColor = (line[18].strip())
                globalHandler.limeColor = (line[19].strip())
                globalHandler.blueColor = (line[20].strip())
                globalHandler.lightBlueColor = (line[21].strip())
                globalHandler.darkBlueColor = (line[22].strip())
                globalHandler.cyanColor = (line[23].strip())
                globalHandler.whiteColor = (line[24].strip())
                globalHandler.greyColor = (line[25].strip())
                globalHandler.blackColor = (line[26].strip())
                globalHandler.purpleColor = (line[27].strip())
                globalHandler.lightGreyColor = (line[28].strip())

            else:
                print("The 'colorScheme.dat' file does not contain enough lines.")
    except FileNotFoundError:
        print("The 'colorScheme.dat' file was not found.")


if __name__ == "__main__":
    print("Run Launcher.pyw or main.py")
    _ = input("Press Enter to exit...")

else:
    print("[Import] IOHandler imported as module")
