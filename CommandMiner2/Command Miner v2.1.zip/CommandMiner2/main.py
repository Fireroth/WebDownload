import tkinter as tk
import tkinter.scrolledtext as scrolledtext
import random

import settings


ver = "2.1"
ore_amount = 0
money = 0
tokens = 0
pickaxe_level = 1
backpack_capacity = 50
saveLoaded = "false"
ore_multiplier = 1
ore_name = "Coal"
common_crate = 0
uncommon_crate = 0
rare_crate = 0
epic_crate = 0
legendary_crate = 0
autosell = 0
rebirth_token_reward = 0

try:
    with open("./DAT/save.dat", "r") as file:
        line = file.readlines()
        
        if len(line) >= 13:
            money = int(line[0].strip())
            ore_amount = int(line[1].strip())
            pickaxe_level = int(line[2].strip())
            backpack_capacity = int(line[3].strip())
            tokens = int(line[4].strip())
            ore_multiplier = int(line[5].strip())
            common_crate = int(line[6].strip())
            uncommon_crate = int(line[7].strip())
            rare_crate = int(line[8].strip())
            epic_crate = int(line[9].strip())
            legendary_crate = int(line[10].strip())
            autosell = int(line[11].strip())
            rebirth_token_reward = int(line[12].strip())

            print("Money:", money)
            print("ore amount:", ore_amount)
            print("pickaxe level:", pickaxe_level)
            print("backpack capacity:", backpack_capacity)
            print("tokens:", tokens)
            print("ore multiplier:", ore_multiplier)
            print("common crates:", common_crate)
            print("uncommon crates:", uncommon_crate)
            print("rare crates:", rare_crate)
            print("epic crates:", epic_crate)
            print("legendary crates:", legendary_crate)
            print("autosell:", autosell)
            print("rebirth_token_reward:", rebirth_token_reward)
            saveLoaded = "true"
        else:
            print("The 'save.dat' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'save.dat' file was not found.")
except ValueError:
    print("Error converting a value from 'save.dat' file to a number.")


try:
    with open("./DAT/config.dat", "r") as file:
        line = file.readlines()
        
        if len(line) >= 4:
            colorsName = (line[0].strip())
            sepChar = (line[1].strip())
            output_font_size = int((line[2].strip()))
            auto_focus = (line[3].strip())

            print("colorsName:", colorsName)
            print("sepChar:", sepChar)
            print("output_font_size:", output_font_size)
            print("auto_focus:", auto_focus)

        else:
            print("The 'config.dat' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'config.dat' file was not found.")


try:
    with open(f"./DAT/colorScheme_{colorsName}.dat", "r") as file:
        line = file.readlines()
        
        if len(line) >= 6:
            globalBg = (line[0].strip())
            consoleBg = (line[1].strip())
            buttonBg = (line[2].strip())
            entryBg = (line[3].strip())
            titleFg = (line[4].strip())
            buttonFg = (line[5].strip())

        else:
            print("The 'colorScheme.dat' file does not contain enough lines.")
except FileNotFoundError:
    print("The 'colorScheme.dat' file was not found.")



pickaxe_price = pickaxe_level*200
backpack_upgrade_cost = backpack_capacity*2
ore_upgrade_cost = ore_multiplier+2

if autosell == 0:
    autosell_next_price = 10
else:
    autosell_next_price = 0

if rebirth_token_reward == 0:
    rebirth_token_reward_next_price = 5
else:
    rebirth_token_reward_next_price = 0

if ore_multiplier == 1:
    ore_name = "Coal"
elif ore_multiplier == 2:
    ore_name = "Iron"
elif ore_multiplier == 3:
    ore_name = "Copper"
elif ore_multiplier == 4:
    ore_name = "Lapis"
elif ore_multiplier == 5:
    ore_name = "Quartz"
elif ore_multiplier == 6:
    ore_name = "Gold"
elif ore_multiplier == 7:
    ore_name = "Redstone"
elif ore_multiplier == 8:
    ore_name = "Diamond"
elif ore_multiplier == 9:
    ore_name = "Emerald"
elif ore_multiplier == 10:
    ore_name = "Netherite"
elif ore_multiplier >= 11:
    ore_name = "Netherite+"


available_commands = {
    "ver": "Display current version",
    "help": "Display available commands",
    "exit": "Close CommandMiner 2",
    "mine": "Mine ores",
    "sell": "Sell ores and get money",
    "upgrade pickaxe": "Upgrade pickaxe",
    "upgrade backpack": "Increase backpack size",
    "upgrade ore": "Upgrade your ore",
    "open <crate_tier>": "Open a desired crate",
    "clear": "Clear all text on the screen",
    "save": "Save your progress",
    "rebirth": "Exchange progress for tokens",
    "tokenshop": "Exchange tokens for skills",
    "stats": "See your statistics",
    "reset": "Resets your progress",
    "settings": "Configure CommandMiner 2",
    "crates": "See the amount of crates you have"
}


def update_top_label():
    top_label.config(text=f"Money: {money}$ | Tokens: {tokens} | Backpack: {ore_amount}/{backpack_capacity} | Pickaxe level: {pickaxe_level} | Ore: {ore_name}")


def process_input():
    user_input = entry.get()
    if user_input.lower() == "exit":
        quit_app()
    elif user_input.lower() == "ver":
        add_output(f"CommandMiner 2 version: {ver}", "lightgreen")
    elif user_input.lower() == "help":
        help_page()
    elif user_input.lower() == "mine" or user_input.lower() == "m":
        mine_ore()
    elif user_input.lower() == "sell" or user_input.lower() == "s":
        sell_ore()
    elif user_input.lower() == "upgrade pickaxe" or user_input.lower() == "u p" or user_input.lower() == "up p":
        upgrade_pickaxe()
    elif user_input.lower() == "upgrade backpack" or user_input.lower() == "u b" or user_input.lower() == "up b" or user_input.lower() == "up bp":
        upgrade_backpack()
    elif user_input.lower() == "upgrade ore" or user_input.lower() == "u o" or user_input.lower() == "up o" or user_input.lower() == "up ore":
        upgrade_ore()
    elif user_input.lower() == "open common" or user_input.lower() == "o common" or user_input.lower() == "o c"or user_input.lower() == "open c":
        open_crate_common()
    elif user_input.lower() == "open uncommon" or user_input.lower() == "o uncommon" or user_input.lower() == "o u"or user_input.lower() == "open u":
        open_crate_uncommon()
    elif user_input.lower() == "open rare" or user_input.lower() == "o rare" or user_input.lower() == "o r"or user_input.lower() == "open r":
        open_crate_rare()
    elif user_input.lower() == "open epic" or user_input.lower() == "o epic" or user_input.lower() == "o e"or user_input.lower() == "open e":
        open_crate_epic()
    elif user_input.lower() == "open legendary" or user_input.lower() == "o legendary" or user_input.lower() == "o l"or user_input.lower() == "open l":
        open_crate_legendary()
    elif user_input.lower() == "tokenshop" or user_input.lower() == "token shop" or user_input.lower() == "tshop" or user_input.lower() == "ts":
        token_shop()
    elif user_input.lower() == "rebirth":
        rebirth()
    elif user_input.lower() == "clear" or user_input.lower() == "cls":
        clear_output()
    elif user_input.lower() == "save":
        save_progress()
    elif user_input.lower() == "stats":
        stats()
    elif user_input.lower() == "allstats":
        allstats()
    elif user_input.lower() == "crates":
        allCrates()
    elif user_input.lower() == "reset":
        reset_progress()
    elif user_input.lower() == "settings":
        entry.delete(0, "end")
        settings.settings()
    elif user_input.lower() == "":
        add_output(f"Empty command!", "red")
    elif user_input.lower() == "buy autosell":
        buy_autosell()
    elif user_input.lower() == "buy rebreward":
        buy_rebreward()
    else:
        add_output(f"Command {user_input} does not exist", 'red')

    if sepChar == "Empty":
        add_output("", "")
    elif sepChar == "Dash":
        add_output("---------------------------------------------------", "")
    entry.delete(0, "end")


def mine_ore():
    global ore_amount, backpack_capacity, common_crate, uncommon_crate, rare_crate, epic_crate, legendary_crate

    mined_amount = random.randint(1, 5) * pickaxe_level
    if ore_amount + mined_amount <= backpack_capacity:

        #crate generator-------------------------------------------------------------------
        if random.randint(1, 1000) >= 980:
            common_crate += 1
            add_output("You obtained 1 common crate", "white")
        elif random.randint(1, 1700) >= 1690:
            uncommon_crate += 1
            add_output("You obtained 1 uncommon crate", "lightgreen")
        elif random.randint(1, 3000) >= 2990:
            rare_crate += 1
            add_output("You obtained 1 rare crate", "lightblue")
        elif random.randint(1, 5000) >= 4996:
            epic_crate += 1
            add_output("You obtained 1 epic crate", "purple")
        elif random.randint(1, 7500) >= 7499:
            legendary_crate += 1
            add_output("You obtained 1 legendary crate", "yellow")
        #crate generator-------------------------------------------------------------------

        ore_amount += mined_amount
        add_output(f"You obtained {mined_amount} units of {ore_name}. Total ore in backpack: {ore_amount}", "lightgrey")
    elif ore_amount == backpack_capacity and autosell == 1:
        sell_ore()
    elif ore_amount == backpack_capacity:
        add_output("Backpack is full. Sell some ore or free up space in backpack.", "red")
    else:
        ore_amount = backpack_capacity
        add_output(f"You obtained {mined_amount} units of {ore_name}. Total ore in backpack: {ore_amount}", "lightgrey")
    update_top_label()


def sell_ore():
    global ore_amount, money
    if ore_amount > 0:

        sale_amount = ore_amount * ore_multiplier
        money += sale_amount
        add_output(f"You sold {ore_amount} {ore_name} for {sale_amount}$. Total money: {money}", "lightgreen")
        ore_amount = 0
    else:
        add_output(f"You have no {ore_name} to sell.", "red")
    update_top_label()


def upgrade_pickaxe():
    global money, pickaxe_level, pickaxe_price
    if money >= pickaxe_price:
        money -= pickaxe_price
        pickaxe_level += 1
        pickaxe_price = pickaxe_level*200
        add_output(f"You upgraded the pickaxe to level {pickaxe_level}. New upgrade price: {pickaxe_price}$.", "lightblue")
    else:
        add_output(f"Not enough money to upgrade the pickaxe. Next upgrade cost {pickaxe_price}$.", "red")
    update_top_label()


def upgrade_backpack():
    global money, backpack_capacity, backpack_upgrade_cost
    if money >= backpack_upgrade_cost:
        money -= backpack_upgrade_cost
        backpack_capacity += 25
        backpack_upgrade_cost = backpack_capacity*2
        add_output(f"You increased backpack capacity to {backpack_capacity}. New upgrade price: {backpack_upgrade_cost}$.", "lightblue")
    else:
        add_output(f"Not enough money to increase backpack capacity. Next upgrade cost {backpack_upgrade_cost}$.", "red")
    update_top_label()


def upgrade_ore():
    global tokens, ore_multiplier, ore_upgrade_cost
    if tokens >= ore_upgrade_cost:
        tokens -= ore_upgrade_cost
        ore_multiplier +=1
        ore_upgrade_cost = ore_upgrade_cost+2
        add_output(f"You increased ore to {ore_name} ores. New upgrade price: {ore_upgrade_cost} tokens.", "lightblue")
    else:
        add_output(f"Not enough tokens to increase ore. Next upgrade cost {ore_upgrade_cost} tokens.", "red")
    update_top_label()


def open_crate_common():
    global money, common_crate
    if common_crate <= 0:
        add_output(f"You have no common crates to open.", "red")
    else:
        common_crate -= 1
        crateMoney = random.randint(1, 200)
        if crateMoney < 150:
            crateMoney = 0
            add_output(f"You got {crateMoney}$ from common crate", "red")
            add_output(f"Sorry but you got unlucky this time :(", "red")
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from common crate", "lightgreen")
    update_top_label()


def open_crate_uncommon():
    global money, uncommon_crate
    if uncommon_crate <= 0:
        add_output(f"You have no uncommon crates to open.", "red")
    else:
        uncommon_crate -= 1
        crateMoney = random.randint(1, 400)
        if crateMoney < 475:
            crateMoney = 0
            add_output(f"You got {crateMoney}$ from uncommon crate", "red")
            add_output(f"Sorry but you got unlucky this time :(", "red")
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from uncommon crate", "lightgreen")
    update_top_label()


def open_crate_rare():
    global money, rare_crate
    if rare_crate <= 0:
        add_output(f"You have no rare crates to open.", "red")
    else:
        rare_crate -= 1
        crateMoney = random.randint(1, 625)
        if crateMoney < 620:
            crateMoney = 0
            add_output(f"You got {crateMoney}$ from rare crate", "red")
            add_output(f"Sorry but you got unlucky this time :(", "red")
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from rare crate", "lightgreen")
    update_top_label()


def open_crate_epic():
    global money, epic_crate
    if epic_crate <= 0:
        add_output(f"You have no epic crates to open.", "red")
    else:
        epic_crate -= 1
        crateMoney = random.randint(1, 925)
        if crateMoney > 50:
            crateMoney = 50
            add_output(f"You got {crateMoney}$ from epic crate", "lightgreen")
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from epic crate", "lightgreen")
    update_top_label()


def open_crate_legendary():
    global money, legendary_crate
    if legendary_crate <= 0:
        add_output(f"You have no legendary crates to open.", "red")
    else:
        legendary_crate -= 1
        crateMoney = random.randint(1, 1300)
        if crateMoney > 150:
            crateMoney = 150
            add_output(f"You got {crateMoney}$ from epic crate", "lightgreen")
        else:
            money += crateMoney
            add_output(f"You got {crateMoney}$ from legendary crate", "lightgreen")
    update_top_label()


def stats():
    add_output(f"Money: {money}", "lightblue")
    add_output(f"Tokens: {tokens}", "lightblue")
    add_output(f"Pickaxe level: {pickaxe_level}", "lightblue")
    add_output(f"Backpack size: {backpack_capacity}", "lightblue")
    add_output(f"Ore multiplier: {ore_multiplier}", "lightblue")

def allstats():
    add_output(f"Money: {money}", "lightblue")
    add_output(f"Tokens: {tokens}", "lightblue")
    add_output(f"Pickaxe level: {pickaxe_level}", "lightblue")
    add_output(f"Pickaxe max mine: {pickaxe_level*5}", "lightblue")
    add_output(f"Pickaxe upgrade price: {pickaxe_price}$", "lightblue")
    add_output(f"Backpack size: {backpack_capacity}", "lightblue")
    add_output(f"Backpack upgrade price: {backpack_upgrade_cost}$", "lightblue")
    add_output(f"Ore multiplier: {ore_multiplier}", "lightblue")
    add_output(f"Ore name: {ore_name}", "lightblue")
    add_output(f"Ore amount in BP: {ore_amount}", "lightblue")
    add_output(f"Ore upgrade price: {ore_upgrade_cost} tokens", "lightblue")
    


def allCrates():
    add_output(f"Common: {common_crate}", "white")
    add_output(f"Uncommon: {uncommon_crate}", "lightgreen")
    add_output(f"Rare: {rare_crate}", "lightblue")
    add_output(f"Epic: {epic_crate}", "purple")
    add_output(f"Legendary: {legendary_crate}", "yellow")


def help_page():
    add_output("Available commands:", "white")
    for command, description in available_commands.items():
        add_output(f"- {command}: {description}", "white")


def token_shop():
    global autosell, rebirth_token_reward, rebirth_token_reward_next_price, autosell_next_price

    add_output("Autosell", "lightgreen")
    add_output(f"|| Current level: {autosell}", "lightgreen")
    add_output(f"|| Upgrade price: {autosell_next_price}", "lightgreen")
    add_output(f"|| Upgrade command: buy autosell", "lightgreen")
    add_output("", "")
    add_output("Rebirth token reward", "pink")
    add_output(f"|| Current level: {rebirth_token_reward}", "pink")
    add_output(f"|| Upgrade price: {rebirth_token_reward_next_price}", "pink")
    add_output(f"|| Upgrade command: buy rebreward", "pink")


def buy_autosell():
    global tokens, autosell, autosell_next_price
    if autosell == 1:
        add_output("Autosell has reached its maximum level", "red")
    elif tokens >= autosell_next_price:
        tokens -= autosell_next_price
        autosell = 1
        add_output(f"Autosell has been upgraded to level 1 for {autosell_next_price} tokens", "lightgreen")
        autosell_next_price = 0
        update_top_label()
    else:
        add_output("Not enough tokens to buy Autosell", "red")


def buy_rebreward():
    global tokens, rebirth_token_reward_next_price, rebirth_token_reward
    if rebirth_token_reward == 1:
        add_output("Rebirth token reward has reached its maximum level", "red")
    elif tokens >= rebirth_token_reward_next_price:
        tokens -= rebirth_token_reward_next_price
        rebirth_token_reward = 1
        add_output(f"Rebirth token reward has been upgraded to level 1 for {rebirth_token_reward_next_price} tokens", "lightgreen")
        rebirth_token_reward_next_price = 0
        update_top_label()
    else:
        add_output("Not enough tokens to buy Rebirth token reward", "red")


def save_progress():
    try:
        with open("./DAT/save.dat", "w") as file:
            file.write(str(money) + "\n")
            file.write(str(ore_amount) + "\n")
            file.write(str(pickaxe_level) + "\n")
            file.write(str(backpack_capacity) + "\n")
            file.write(str(tokens) + "\n")
            file.write(str(ore_multiplier) + "\n")
            file.write(str(common_crate) + "\n")
            file.write(str(uncommon_crate) + "\n")
            file.write(str(rare_crate) + "\n")
            file.write(str(epic_crate) + "\n")
            file.write(str(legendary_crate) + "\n")
            file.write(str(autosell) + "\n")
            file.write(str(rebirth_token_reward) + "\n")
        print("Data has been successfully written to the 'save.dat' file.")
        add_output("Saving succesfull.", "lightgreen")

    except IOError:
        print("Error writing to the 'save.txt' file.")


def reset_progress():
    global money, pickaxe_level, backpack_capacity, ore_amount, tokens, ore_multiplier, common_crate, uncommon_crate, rare_crate, epic_crate, legendary_crate, autosell, rebirth_token_reward
    money = 0
    pickaxe_level = 1
    backpack_capacity = 50
    ore_amount = 0
    tokens = 0
    ore_multiplier = 1
    common_crate = 0
    uncommon_crate = 0
    rare_crate = 0
    epic_crate = 0
    legendary_crate = 0
    autosell = 0
    rebirth_token_reward = 0
    update_top_label()
    add_output("Reset succesfull.", "lightgreen")
    add_output("Save to make the changes permanent", "lightgreen")


def rebirth():
    global backpack_capacity, pickaxe_level, tokens, money, ore_amount
    if pickaxe_level >= 200:
        pickaxe_level = 1
        backpack_capacity = 50
        money = 0
        ore_amount = 0
        if rebirth_token_reward == 1:
            tokens += 2
            add_output("Rebirth was succesfull. +2 Tokens", "lightgreen")
        else:
            tokens += 1
            add_output("Rebirth was succesfull. +1 Token", "lightgreen")
        update_top_label()
    else:
        add_output("Failed to rebirth you need pickaxe level 200 or higher.", "red")


def clear_output():
    output_text.config(state=tk.NORMAL)
    output_text.delete(1.0, tk.END)
    output_text.config(state=tk.DISABLED)


def quit_app():
    root.destroy()


def add_output(text, color):
    output_text.config(state=tk.NORMAL)
    output_text.insert(tk.END, text + "\n", color)
    output_text.tag_config(color, foreground=color)
    output_text.see(tk.END)
    output_text.config(state=tk.DISABLED)


def on_enter(event):
    process_input()


def on_entry_focus_in(event):
    if entry.get() == placeholder_text:
        entry.delete(0, tk.END)
        entry.configure(show="")
        entry.configure(fg=f'{titleFg}')


def on_entry_focus_out(event):
    if entry.get() == "":
        entry.insert(0, placeholder_text)
        entry.configure(show="")
        entry.configure(fg="white")


root = tk.Tk()
root.title("CommandMiner 2")
root.geometry("900x500")
root.minsize(width=600, height=400)

icon = tk.PhotoImage(file="./images/Icon.png")
root.iconphoto(True, icon)

root.tk_setPalette(background=f'{globalBg}', foreground='white')

top_label = tk.Label(root, text=f"Money: {money}$ | Tokens: {tokens} | Backpack: {ore_amount}/{backpack_capacity} | Pickaxe level: {pickaxe_level} | Ore: {ore_name}", bg=f"{globalBg}", fg=f"{titleFg}")
top_label.pack(pady=10)

output_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, state=tk.DISABLED, background=f'{consoleBg}', fg="white", height=15, font=("", output_font_size))
output_text.pack(expand=True, fill="both")

placeholder_text = "Enter command here..."
entry = tk.Entry(root, background=f'{entryBg}', fg=f'{titleFg}', insertbackground='white', font=("", 17))
entry.insert(0, placeholder_text)
entry.bind("<FocusIn>", on_entry_focus_in)
entry.bind("<FocusOut>", on_entry_focus_out)
if auto_focus == "True":
    entry.focus()
entry.pack(pady=5, fill='x')

button_frame = tk.Frame(root, background=f'{globalBg}')
button_frame.pack()

quit_button = tk.Button(button_frame, text="Quit", command=quit_app, background=f'{buttonBg}', fg=f'{buttonFg}')
quit_button.pack(side=tk.LEFT, padx=5)

process_button = tk.Button(button_frame, text="Process", command=process_input, background=f'{buttonBg}', fg=f'{buttonFg}')
process_button.pack(side=tk.LEFT, padx=5)


help_button = tk.Button(button_frame, text="Help", command=help_page, background=f'{buttonBg}', fg=f'{buttonFg}')
help_button.pack(side=tk.LEFT, padx=5)

settings_button = tk.Button(button_frame, text="Settings", command=settings.settings, background=f'{buttonBg}', fg=f'{buttonFg}')
settings_button.pack(side=tk.LEFT, padx=5)


entry.bind("<Return>", on_enter)

add_output(f"CommandMiner 2 version: {ver}", "lightgreen")
if saveLoaded == "true":
    add_output("Save file loaded succesfully.", "lightgreen")
else:
    add_output("Save file was not loaded.", "red")

root.mainloop()
